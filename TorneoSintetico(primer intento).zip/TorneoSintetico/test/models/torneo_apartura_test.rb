require 'test_helper'

class TorneoAparturaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
